$(document).ready(function() {
  //start ajax request
  var formId= $("#formId").val();
  var formData = [];
  $.ajax({
    url: "formdata.txt",
    //force to handle it as text
    dataType: "text",
    success: function(data) {
      var result = $.parseJSON(data);
 	  formData = result[formId]==null?[]:result[formId];
      $.each(formData, function() {
        $('#LocationID').append("<option value=" + this.ID + ">" + this.DisplayValue + "</option>");
      });
    }
  });
  
  $('#LocationID').change(function() {
    var optionsData = '<option selected="selected" value="">Select a Program</option>';
    var hasProgram = false;
    var getValue = $(this).val();
    $.each(formData, function() {
      var locationid = this.ID;
      if (getValue == locationid) {
        hasProgram = true;
        $.each(this.Curriculum, function() {
          optionsData += "<option value=" + this.CurriculumID + ">" + this.CurriculumDisplayValue + "</option>";
        });
      }
    });

    if (hasProgram) {
      $("#CurriculumID").html(optionsData);
    }

  });
});